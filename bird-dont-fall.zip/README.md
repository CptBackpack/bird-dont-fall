# Bird, Don't Fall!
**Bird, Don't Fall!** is a HTML5 game in which you have to take care of your pet parrot.  
>Your bird just got his wings trimmed, and because of that he cannot fly that good anymore. That made him angry, and now he tries to jump in attempt to fly. Your job is to keep it safe and not allow him to touch the ground.
Your tools to do so are your hands. Place your hands where you would expect your bird to jump to give him a boost and prevent his fall.  
... but, there's a problem! The bird goes crazier and crazier, and will start jumping around more chaotic the more you keep it from the ground.
Good luck!

[Bird, Don't Fall! on itch.io](https://cptbackpack.itch.io/bird-dont-fall)
## Development 
The HTML5 game is still in development. 
The development is done using the [Phaser](https://github.com/photonstorm/phaser) game engine.

## Contact the developer
On [Facebook](https://www.facebook.com/truta.r96), or on [Twitter @rvBackpack](https://twitter.com/rvbackpack)
